package lsalih.deezerjavafxgui.deezer.control;

public class Controller {
}
