package lsalih.deezerjavafxgui.deezer.view;

public class SearchView {
}
