package lsalih.deezerjavafxgui.deezer;

import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import lsalih.deezerjavafxgui.deezer.model.SearchArtistTrackAlbum;

import java.io.IOException;
import java.util.List;

public class Controller {
    private Stage stage;
    private BorderPane root;



    public Controller(Stage stage) {
        // Bühne in einer Instanzvariablen ablegen
        this.stage=stage;

        // Model erzeugen
        String search = "";
        WebserviceDeezerDao dao = new WebserviceDeezerDao();
        List<SearchArtistTrackAlbum> result = null;
        try {
            result = dao.searchArtistTrackAlbum(search);
        }
        catch (IOException e){
            System.out.println("Daten konnten nicht gefunden werden!");
        }
//        System.out.println(result);

        // Basis Layout erzeugen
        root = new BorderPane();


    }
}
