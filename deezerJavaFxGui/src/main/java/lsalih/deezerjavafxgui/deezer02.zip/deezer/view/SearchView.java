package lsalih.deezerjavafxgui.deezer.view;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class SearchView extends VBox {

    private Label searchLabel;
    private TextField searchField;
    private Button searchButton;

    public SearchView() {

        searchLabel = new Label("Search");
        searchField = new TextField("Song, Artist, Album");
        searchButton = new Button("Search...");

        this.getChildren().add(searchLabel);
        HBox hBox = new HBox();
        hBox.getChildren().addAll(searchField, searchButton);
        this.getChildren().add(hBox);
    }

    public Label getSearchLabel() {
        return searchLabel;
    }

    public TextField getSearchField() {
        return searchField;
    }

    public Button getSearchButton() {
        return searchButton;
    }
}
