package lsalih.deezerjavafxgui.deezer.control;

import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import lsalih.deezerjavafxgui.deezer.dao.DeezerDao;
import lsalih.deezerjavafxgui.deezer.dao.WebserviceDeezerDao;
import lsalih.deezerjavafxgui.deezer.model.SearchArtistTrackAlbum;
import lsalih.deezerjavafxgui.deezer.view.ResultList;
import lsalih.deezerjavafxgui.deezer.view.SearchView;

import java.io.IOException;
import java.util.List;

public class Controller {

    private Stage stage;
    private GridPane gridPane;
    private ResultList resultList;
    SearchView searchView;


    private void getSearchResults(){
        String search = searchView.getSearchField().getText();
        WebserviceDeezerDao dao = new WebserviceDeezerDao();

        List<SearchArtistTrackAlbum> result = null;
        try {
            result = dao.searchArtistTrackAlbum(search);
        }
        catch (IOException e){
            System.out.println("Daten konnten nicht gefunden werden!");
        }
        resultList.setResultList(result);
    }


    public Controller(Stage stage) throws IOException {
        this.stage = stage;

        searchView = new SearchView();
//        DeezerDao dao = new WebserviceDeezerDao();
//        List<SearchArtistTrackAlbum> searchArtistTrackAlbumList = dao.searchArtistTrackAlbum(searchView.getSearchField().getText());

        resultList = new ResultList();
        resultList.getSelectionModel();

        gridPane = new GridPane();
        gridPane.setHgap(20);
        gridPane.setVgap(20);
        gridPane.addRow(0, searchView);
        gridPane.addRow(1,resultList);

        searchView.getSearchButton().setOnAction(e -> getSearchResults());

        Scene scene = new Scene(gridPane, 500,800);

        stage.setScene(scene);

        stage.show();



    }



}
